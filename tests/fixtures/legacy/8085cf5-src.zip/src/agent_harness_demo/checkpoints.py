"""A recovery checkpoint contains verified pairs, never invented tool results."""

from copy import deepcopy
import json
from typing import Any

from .context import history_turn

Record = dict[str, Any]


def checkpoint_payload(run: Record, events: list[Record], artifacts: list[Record]) -> Record:
    ancestor = json.loads(run.get("resume_json") or "null") or {}
    pending: dict[str, Record] = {}
    for attempt in ancestor.get("pending", []):
        if attempt.get("error", {}).get("retryable"):
            key = f"recovery-{ancestor['source_run_id']}-{attempt['call_id']}"
            pending[key] = {**deepcopy(attempt), "call_id": key}
    confirmed: list[Record] = deepcopy(ancestor.get("confirmed", []))
    seen_calls: set[str] = set()
    protocol_blockers: list[Record] = []
    for event in events:
        kind, data = event["kind"], event["data"]
        if kind == "model.responded":
            for call in data.get("message", {}).get("tool_calls", []):
                identity = call["id"]
                if identity in seen_calls:
                    protocol_blockers.append({"call_id": identity, "code": "ambiguous_call_identity"})
                    continue
                seen_calls.add(identity)
                try:
                    arguments = call["function"]["arguments"]
                    arguments = json.loads(arguments) if isinstance(arguments, str) else deepcopy(arguments)
                    if not isinstance(arguments, dict):
                        raise ValueError
                except (ValueError, TypeError):
                    protocol_blockers.append({"call_id": identity, "code": "invalid_saved_call"})
                    continue
                pending[identity] = {"call_id": identity, "tool": call["function"]["name"],
                                     "arguments": arguments, "status": "not_dispatched"}
        elif kind == "tool.requested":
            pending[data["call_id"]] = {**deepcopy(data), "status": "not_dispatched"}
        elif kind == "tool.dispatched":
            pending[data["call_id"]] = {**deepcopy(data), "status": "unknown"}
        elif kind in {"tool.completed", "tool.reconciled", "tool.reused"}:
            intent = pending.pop(data["call_id"], None)
            if intent is not None:
                record = {**intent, **deepcopy(data), "origin_run_id": run["id"], "status": "confirmed", "result": deepcopy(data["result"])}
                if kind != "tool.reused":
                    confirmed.append(record)
        elif kind in {"tool.failed", "tool.rejected"} and data["call_id"] in pending:
            pending[data["call_id"]]["status"] = "failed" if kind == "tool.failed" else "rejected"
        elif kind == "correction.available" and data["call_id"] in pending:
            pending[data["call_id"]]["error"] = deepcopy(data["error"])
            for identity in data.get("superseded_call_ids", []):
                pending.pop(identity, None)
        elif kind == "correction.observed":
            for identity in data["failed_call_ids"]:
                pending.pop(identity, None)

    raw = history_turn(run["id"], run["task"], events)[1:]
    messages: list[Record] = deepcopy(ancestor.get("messages", []))
    index = 0
    while index < len(raw):
        assistant = raw[index]
        index += 1
        if assistant["role"] != "assistant":
            continue
        results: dict[str, Record] = {}
        while index < len(raw) and raw[index]["role"] == "tool":
            results[raw[index]["tool_call_id"]] = raw[index]
            index += 1
        if not assistant.get("tool_calls"):
            messages.append(assistant)
            continue
        calls = [call for call in assistant["tool_calls"] if call["id"] in results]
        if calls:
            messages.append({**assistant, "tool_calls": calls})
            messages.extend(results[call["id"]] for call in calls)

    blockers = protocol_blockers + [{"call_id": call["call_id"], "code": "unknown_effect", "effect": call.get("effect", "unknown")}
                for call in pending.values() if call["status"] == "unknown" and call.get("effect") not in {"read_only", "run_metadata"}]
    return {"version": 1, "source_run_id": run["id"], "task": run["task"],
            "sources": json.loads(run["sources_json"]), "limits": json.loads(run["limits_json"]),
            "model": json.loads(run["model_json"]), "policy": json.loads(run["policy_json"]),
            "confirmed": confirmed, "pending": list(pending.values()), "messages": messages,
            "artifacts": list({item["id"]: item for item in [*ancestor.get("artifacts", []), *artifacts]}.values()), "blockers": blockers}
