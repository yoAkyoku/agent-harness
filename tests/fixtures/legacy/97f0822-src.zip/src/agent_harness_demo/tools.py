"""Validated, scoped tools used by every Run, independent of task wording."""

import asyncio
from copy import deepcopy
from collections.abc import Awaitable, Callable
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, ValidationError

from .arithmetic_evidence import require_csv_arithmetic_evidence
from .contracts import PreparedCall, RunFailure, ToolCall, canonical_tool_arguments
from .sources import MAX_SOURCE_BYTES, MAX_SOURCE_PATH, MAX_SOURCES, labelled_source_lines, query_source_labels, read_source
from .storage import Record, Store
from .tables import ratio_percent, table_result

# Accommodate every admitted source plus bounded UTF-8 path headings and the fixture notice.
MAX_ARTIFACT_BYTES = MAX_SOURCES * MAX_SOURCE_BYTES + 32_768
PATH_SCHEMA = {"type": "string", "minLength": 1, "maxLength": MAX_SOURCE_PATH}
EVIDENCE_SCHEMA = {"type": "string", "pattern": "^E[1-9][0-9]*$"}

DEFINITIONS: dict[str, Record] = {
    "plan_update": {
        "effect": "run_metadata",
        "description": "Save/revise the public action plan before substantive work. No private reasoning.",
        "parameters": {"type": "object", "properties": {"steps": {"type": "array", "minItems": 1, "maxItems": 8,
            "items": {"type": "string", "minLength": 1, "maxLength": 200}}}, "required": ["steps"], "additionalProperties": False},
    },
    "table_inspect": {
        "effect": "read_only",
        "description": "Inspect CSV headers, rows, sample, hash and lines. Samples are not aggregate evidence: use table_aggregate even if all rows fit.",
        "parameters": {"type": "object", "properties": {"path": PATH_SCHEMA}, "required": ["path"], "additionalProperties": False},
    },
    "table_aggregate": {
        "effect": "read_only",
        "description": "Sum/mean a full numeric CSV column; return numeric evidence_id for calculation/citation.",
        "parameters": {"type": "object", "properties": {"path": PATH_SCHEMA,
            "column": {"type": "string", "minLength": 1, "maxLength": 100}, "operation": {"enum": ["sum", "mean"]}},
            "required": ["path", "column", "operation"], "additionalProperties": False},
    },
    "number_calculate": {
        "effect": "read_only",
        "description": "ratio_percent: numerator / denominator * 100. Operands must be prior numeric evidence IDs, never literals.",
        "parameters": {"type": "object", "properties": {"operation": {"type": "string", "enum": ["ratio_percent"]},
            "numerator": EVIDENCE_SCHEMA, "denominator": EVIDENCE_SCHEMA},
            "required": ["operation", "numerator", "denominator"], "additionalProperties": False},
    },
    "workspace_list": {
        "effect": "read_only",
        "description": "List this task's selected sources.",
        "parameters": {"type": "object", "properties": {}, "additionalProperties": False},
    },
    "source_read": {
        "effect": "read_only",
        "description": "Read UTF-8/hash. labels=[] reads raw; otherwise query exact case-sensitive colon labels. complete=false means unavailable, not absent. Not a semantic schema.",
        "parameters": {"type": "object", "properties": {"path": PATH_SCHEMA,
            "labels": {"type": "array", "minItems": 0, "maxItems": 8, "uniqueItems": True,
                       "items": {"type": "string", "minLength": 1, "maxLength": 100}}},
                       "required": ["path"], "additionalProperties": False},
    },
    "artifact_write": {
        "effect": "immutable_artifact",
        "description": "Publish immutable Markdown/text for this Run.",
        "parameters": {"type": "object", "properties": {
            "name": {"type": "string", "minLength": 1, "maxLength": 100, "pattern": r"^[^/\\:\x00-\x1f]+$"},
            "content": {"type": "string", "minLength": 1, "maxLength": MAX_ARTIFACT_BYTES},
            "citations": {"type": "array", "maxItems": 20, "uniqueItems": True, "items": EVIDENCE_SCHEMA},
        }, "required": ["name", "content"], "additionalProperties": False},
    },
    "task_finish": {
        "effect": "run_metadata",
        "description": "Declare completion after confirmed publication.",
        "parameters": {"type": "object", "properties": {
            "summary": {"type": "string", "minLength": 1, "maxLength": 512, "pattern": r"\S"}},
            "required": ["summary"], "additionalProperties": False},
    },
}


def model_tools(*, require_citations: bool = False, include_tables: bool = True, include_labels: bool = True,
                include_finish: bool = False) -> list[Record]:
    definitions = deepcopy(DEFINITIONS)
    if not include_finish:
        del definitions["task_finish"]
    if not include_labels:
        del definitions["source_read"]["parameters"]["properties"]["labels"]
        definitions["source_read"]["description"] = "Read a selected UTF-8 source with hash."
    else:
        definitions["source_read"]["parameters"]["required"].append("labels")
    if not include_tables:
        for name in ("table_inspect", "table_aggregate", "number_calculate"):
            del definitions[name]
    if require_citations:
        parameters = definitions["artifact_write"]["parameters"]
        parameters["required"].append("citations")
        parameters["properties"]["citations"]["minItems"] = 1
    return [{"type": "function", "function": {"name": name, "description": definition["description"],
             "parameters": definition["parameters"]}} for name, definition in definitions.items()]


class Tools:
    def __init__(self, store: Store, run_id: str, root: Path, sources: list[Record], *, require_citations: bool = False,
                 fault_once_source_read: bool = False) -> None:
        self.store = store
        self.run_id = run_id
        self.root = root
        self.sources = {source["path"]: source for source in sources}
        self.evidence: dict[str, Record] = {}
        self.require_citations = require_citations
        self._fault_pending = fault_once_source_read
        self.actions: dict[str, Callable[[Record], Awaitable[Record]]] = {
            "plan_update": self._plan,
            "table_inspect": self._inspect,
            "table_aggregate": self._aggregate,
            "number_calculate": self._calculate,
            "workspace_list": self._list,
            "source_read": self._read,
            "task_finish": self._finish,
        }

    def restore_evidence(self, confirmed: list[Record]) -> None:
        for call in confirmed:
            result = call["result"]
            if "evidence_id" not in result:
                continue
            if call["tool"] not in {"source_read", "table_inspect", "table_aggregate", "number_calculate"}:
                raise RunFailure("checkpoint_evidence_invalid", "The checkpoint contains an unsupported evidence producer.")
            if "path" in result:
                source = self.sources.get(result["path"])
                if source is None or source["sha256"] != result["sha256"]:
                    raise RunFailure("checkpoint_evidence_invalid", "Restored evidence must match selected source versions.")
            elif any(identity not in self.evidence for identity in result.get("inputs", [])):
                raise RunFailure("checkpoint_evidence_invalid", "Restored calculation evidence is missing its source inputs.")
            identity = result["evidence_id"]
            if identity in self.evidence and self.evidence[identity] != result:
                raise RunFailure("checkpoint_evidence_invalid", "The checkpoint contains conflicting evidence identities.")
            self.evidence[identity] = deepcopy(result)

    def validate(self, call: ToolCall) -> None:
        if call.name not in DEFINITIONS:
            raise RunFailure("unknown_tool", "The requested tool is not available to this Run.")
        try:
            Draft202012Validator(DEFINITIONS[call.name]["parameters"]).validate(call.arguments)
        except ValidationError as error:
            hint = f" Allowed values: {error.validator_value!r}." if error.validator in {"enum", "const"} else ""
            path = list(error.absolute_path)
            fields: tuple[str, ...] = ()
            if path and isinstance(path[0], str):
                fields = (path[0],)
            elif error.validator == "required" and isinstance(error.validator_value, list):
                fields = tuple(field for field in error.validator_value if isinstance(field, str) and field not in call.arguments)
            elif error.validator == "additionalProperties":
                properties = DEFINITIONS[call.name]["parameters"]["properties"]
                fields = tuple(field for field in call.arguments if field not in properties)
            raise RunFailure("invalid_arguments", f"Invalid tool input at {error.json_path}: {error.validator} constraint.{hint}", correctable_fields=fields) from error
        if call.name in {"source_read", "table_inspect", "table_aggregate"} and call.arguments["path"] not in self.sources:
            raise RunFailure("source_forbidden", "The requested source was not selected for this task.")
        if call.name in {"table_inspect", "table_aggregate"} and Path(call.arguments["path"]).suffix.lower() != ".csv":
            raise RunFailure("invalid_arguments", "Table tools require a selected CSV file.")
        references = call.arguments.get("citations", []) if call.name == "artifact_write" else []
        if call.name == "number_calculate":
            references = [call.arguments["numerator"], call.arguments["denominator"]]
        if any(reference not in self.evidence for reference in references):
            fields = ("citations",) if call.name == "artifact_write" else tuple(
                field for field in ("numerator", "denominator") if call.arguments[field] not in self.evidence)
            raise RunFailure("invalid_evidence", "Only evidence produced by this Run can be referenced.", correctable_fields=fields)
        if call.name == "number_calculate" and any("value" not in self.evidence[ref] for ref in references):
            fields = tuple(field for field in ("numerator", "denominator") if "value" not in self.evidence[call.arguments[field]])
            raise RunFailure("invalid_evidence", "Calculation operands must reference numeric evidence.", correctable_fields=fields)
        if call.name == "artifact_write":
            if self.require_citations and not references:
                raise RunFailure("missing_evidence", "Local model artifacts require at least one citation to evidence produced by this Run.", correctable_fields=("citations",))
            name = call.arguments["name"]
            if name.startswith(".") or Path(name).suffix.lower() not in {".md", ".txt"}:
                raise RunFailure("invalid_arguments", "Use a plain Markdown or text filename.", correctable_fields=("name",))
            if len(call.arguments["content"].encode("utf-8")) > MAX_ARTIFACT_BYTES:
                raise RunFailure("invalid_arguments", "Artifact content exceeds the bounded snapshot capacity.", correctable_fields=("content",))

    def prepare(self, call: ToolCall) -> PreparedCall:
        self.validate(call)
        arguments = self._artifact_arguments(call.arguments) if call.name == "artifact_write" else canonical_tool_arguments(call.name, call.arguments)
        return PreparedCall(call, arguments, {"workspace": str(self.root),
            "artifact_directory": str(self.store.directory / "artifacts"), "effect": DEFINITIONS[call.name]["effect"],
            "sources": deepcopy(list(self.sources.values()))})

    async def execute(self, prepared: PreparedCall) -> Record:
        call = prepared.call
        if call.name == "source_read" and self._fault_pending:
            self._fault_pending = False
            await self.store.record(self.run_id, "tool.fault_injected", {
                "call_id": call.identity, "tool": call.name, "kind": "controlled_read_failure", "before_filesystem_access": True,
            })
            raise RunFailure("source_unavailable", "Controlled validation fault: this read failed before filesystem access. A new read request is safe.")
        if call.name == "artifact_write":
            return await self.store.publish(self.run_id, prepared.arguments["name"], prepared.arguments["content"],
                                            call_id=call.identity)
        return await self.actions[call.name](prepared.arguments)

    async def _list(self, arguments: Record) -> Record:
        return {"sources": list(self.sources.values())}

    async def _read(self, arguments: Record) -> Record:
        source = await self._source(arguments["path"])
        labelled = await asyncio.to_thread(labelled_source_lines, source["text"])
        if labelled:
            source["labelled_lines"] = labelled
        if arguments.get("labels"):
            source["label_queries"] = await asyncio.to_thread(query_source_labels, source["text"], arguments["labels"])
        return self._evidence({**source, "line_start": 1, "line_end": max(1, len(source["text"].splitlines()))})

    async def _source(self, path: str) -> Record:
        source = await asyncio.to_thread(read_source, self.root, path)
        if source["sha256"] != self.sources[path]["sha256"]:
            raise RunFailure("source_changed", "The source changed after task admission. Start a new task with its current version.")
        return source

    def _evidence(self, result: Record) -> Record:
        identity = f"E{len(self.evidence) + 1}"
        result["evidence_id"] = identity
        self.evidence[identity] = result
        return result

    async def _plan(self, arguments: Record) -> Record:
        await self.store.record(self.run_id, "plan.updated", arguments)
        return {"saved": True, **arguments}

    async def _finish(self, arguments: Record) -> Record:
        return {"summary": arguments["summary"]}

    async def _inspect(self, arguments: Record) -> Record:
        source = await self._source(arguments["path"])
        return self._evidence(await asyncio.to_thread(table_result, source))

    async def _aggregate(self, arguments: Record) -> Record:
        source = await self._source(arguments["path"])
        return self._evidence(await asyncio.to_thread(table_result, source, arguments["column"], arguments["operation"]))

    async def _calculate(self, arguments: Record) -> Record:
        refs = [arguments["numerator"], arguments["denominator"]]
        return self._evidence({"operation": "ratio_percent", "inputs": refs,
            "value": ratio_percent(self.evidence[refs[0]]["value"], self.evidence[refs[1]]["value"])})

    def _artifact_arguments(self, arguments: Record) -> Record:
        content = arguments["content"]
        references = list(arguments.get("citations", []))
        if references:
            notes = ["\n\n## Verified tool evidence"]
            visited: set[str] = set()
            while references:
                identity = references.pop(0)
                if identity in visited:
                    continue
                visited.add(identity)
                evidence = self.evidence[identity]
                if "path" in evidence:
                    notes.append(f"- [{identity}] {evidence['path']}:L{evidence['line_start']}-L{evidence['line_end']} SHA-256 {evidence['sha256']}"
                                 + (f"; {evidence['operation']}({evidence['column']}) = {evidence['value']}" if "value" in evidence else ""))
                else:
                    references.extend(evidence["inputs"])
                    notes.append(f"- [{identity}] {evidence['operation']}({', '.join(evidence['inputs'])}) = {evidence['value']}")
            require_csv_arithmetic_evidence(content, [self.evidence[identity] for identity in visited])
            appendix = "\n".join(notes) + "\n"
            # A revision may already contain this exact, freshly validated
            # evidence appendix. Keep the proposed bytes; do not append it twice.
            if not content.rstrip("\r\n").endswith(appendix.rstrip("\r\n")):
                content += appendix
        if len(content.encode("utf-8")) > MAX_ARTIFACT_BYTES:
            raise RunFailure("invalid_arguments", "Artifact and source citations exceed the size limit.", correctable_fields=("content",))
        return {"name": arguments["name"], "content": content}
