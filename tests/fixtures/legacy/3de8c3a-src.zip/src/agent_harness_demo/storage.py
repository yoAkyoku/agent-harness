"""SQLite persistence; all connection work runs outside the event loop."""

import asyncio
from collections.abc import Callable
from copy import deepcopy
from pathlib import Path
from datetime import datetime, timedelta, timezone
import hashlib
import json
import sqlite3
from threading import RLock
from typing import Any, TypeVar
from uuid import uuid4

from .context import history_turn
from .contracts import PreparedCall, RunFailure

T = TypeVar("T")
Record = dict[str, Any]
TERMINAL = {"completed", "failed", "interrupted", "cancelled"}


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


class Store:
    def __init__(self, directory: Path) -> None:
        directory.mkdir(parents=True, exist_ok=True)
        self.directory = directory
        self._lock = RLock()
        self._connection = sqlite3.connect(directory / "workspace.sqlite3", check_same_thread=False)
        self._connection.row_factory = sqlite3.Row
        self._connection.execute("PRAGMA foreign_keys=ON")
        self._connection.execute(
            "CREATE TABLE IF NOT EXISTS workspaces (id TEXT PRIMARY KEY, path TEXT UNIQUE, name TEXT)"
        )
        self._connection.executescript("""
            CREATE TABLE IF NOT EXISTS sessions (
                id TEXT PRIMARY KEY, workspace_id TEXT REFERENCES workspaces(id), title TEXT, created_at TEXT
            );
            CREATE TABLE IF NOT EXISTS runs (
                id TEXT PRIMARY KEY, session_id TEXT REFERENCES sessions(id), task TEXT,
                sources_json TEXT, limits_json TEXT, status TEXT, mode TEXT,
                model_calls INTEGER DEFAULT 0, tool_calls INTEGER DEFAULT 0,
                result TEXT DEFAULT '', error_json TEXT, created_at TEXT
            );
            CREATE TABLE IF NOT EXISTS submissions (
                session_id TEXT REFERENCES sessions(id), key TEXT, request_sha256 TEXT,
                run_id TEXT REFERENCES runs(id), PRIMARY KEY(session_id, key)
            );
            CREATE TABLE IF NOT EXISTS events (
                run_id TEXT REFERENCES runs(id), sequence INTEGER, kind TEXT, data_json TEXT, timestamp TEXT,
                PRIMARY KEY (run_id, sequence)
            );
            CREATE TABLE IF NOT EXISTS artifacts (
                id TEXT PRIMARY KEY, run_id TEXT REFERENCES runs(id), name TEXT, sha256 TEXT, bytes INTEGER
            );
            CREATE TABLE IF NOT EXISTS memory_versions (
                id TEXT, workspace_id TEXT REFERENCES workspaces(id), version INTEGER,
                title TEXT, content TEXT, kind TEXT, keywords_json TEXT, origin_json TEXT,
                deleted INTEGER DEFAULT 0, created_at TEXT, updated_at TEXT,
                PRIMARY KEY(id, version)
            );
            CREATE TABLE IF NOT EXISTS approvals (
                id TEXT PRIMARY KEY, run_id TEXT REFERENCES runs(id), call_id TEXT, tool TEXT,
                arguments_json TEXT, scope_json TEXT, parameters_sha256 TEXT, status TEXT,
                created_at TEXT, expires_at TEXT, UNIQUE(run_id, call_id)
            );
        """)
        columns = {row[1] for row in self._connection.execute("PRAGMA table_info(runs)")}
        if "model_json" not in columns:
            self._connection.execute("ALTER TABLE runs ADD COLUMN model_json TEXT NOT NULL DEFAULT '{}'")
        if "validation_json" not in columns:
            self._connection.execute("ALTER TABLE runs ADD COLUMN validation_json TEXT NOT NULL DEFAULT '{}'")
        if "policy_json" not in columns:
            self._connection.execute("ALTER TABLE runs ADD COLUMN policy_json TEXT NOT NULL DEFAULT '{}'")
        if "cancellation_json" not in columns:
            self._connection.execute("ALTER TABLE runs ADD COLUMN cancellation_json TEXT")
        if "base_json" not in columns:
            self._connection.execute("ALTER TABLE runs ADD COLUMN base_json TEXT")
        if "context_json" not in columns:
            self._connection.execute("ALTER TABLE runs ADD COLUMN context_json TEXT NOT NULL DEFAULT '{}'")
        artifact_columns = {row[1] for row in self._connection.execute("PRAGMA table_info(artifacts)")}
        if "parent_artifact_id" not in artifact_columns:
            self._connection.execute("ALTER TABLE artifacts ADD COLUMN parent_artifact_id TEXT REFERENCES artifacts(id)")
        if "version" not in artifact_columns:
            self._connection.execute("ALTER TABLE artifacts ADD COLUMN version INTEGER NOT NULL DEFAULT 1")
        self._connection.commit()

    def _transaction(self, operation: Callable[[sqlite3.Connection], T]) -> T:
        with self._lock, self._connection:
            return operation(self._connection)

    async def _run(self, operation: Callable[[sqlite3.Connection], T]) -> T:
        return await asyncio.to_thread(self._transaction, operation)

    async def add_workspace(self, root: Path) -> Record:
        def add(connection: sqlite3.Connection) -> Record:
            connection.execute(
                "INSERT OR IGNORE INTO workspaces VALUES (?, ?, ?)",
                (uuid4().hex, str(root), root.name or str(root)),
            )
            row = connection.execute("SELECT * FROM workspaces WHERE path=?", (str(root),)).fetchone()
            assert row is not None
            return dict(row)

        return await self._run(add)

    async def workspaces(self) -> list[Record]:
        return await self._run(
            lambda connection: [dict(row) for row in connection.execute("SELECT * FROM workspaces ORDER BY rowid")]
        )

    async def workspace(self, identity: str) -> Record | None:
        def get(connection: sqlite3.Connection) -> Record | None:
            row = connection.execute("SELECT * FROM workspaces WHERE id=?", (identity,)).fetchone()
            return dict(row) if row else None

        return await self._run(get)

    async def close(self) -> None:
        def close() -> None:
            with self._lock:
                self._connection.close()

        await asyncio.to_thread(close)

    @staticmethod
    def _memory(row: sqlite3.Row) -> Record:
        memory = dict(row)
        memory["keywords"] = json.loads(memory.pop("keywords_json"))
        memory["origin"] = json.loads(memory.pop("origin_json"))
        memory["deleted"] = bool(memory["deleted"])
        return memory

    async def add_memory(self, workspace_id: str, title: str, content: str, kind: str,
                         keywords: list[str], source_note: str) -> Record:
        identity, timestamp = uuid4().hex, now()
        def save(connection: sqlite3.Connection) -> Record:
            connection.execute("INSERT INTO memory_versions VALUES (?, ?, 1, ?, ?, ?, ?, ?, 0, ?, ?)",
                (identity, workspace_id, title, content, kind, json.dumps(keywords, ensure_ascii=False),
                 json.dumps({"kind": "user", "note": source_note}, ensure_ascii=False), timestamp, timestamp))
            row = connection.execute("SELECT * FROM memory_versions WHERE id=? AND version=1", (identity,)).fetchone()
            assert row is not None
            return self._memory(row)
        return await self._run(save)

    async def memories(self, workspace_id: str) -> list[Record]:
        def get(connection: sqlite3.Connection) -> list[Record]:
            return [self._memory(row) for row in connection.execute(
                "SELECT * FROM memory_versions m WHERE workspace_id=? AND deleted=0 AND "
                "version=(SELECT MAX(version) FROM memory_versions WHERE id=m.id) ORDER BY created_at, id", (workspace_id,))]
        return await self._run(get)

    async def memory(self, workspace_id: str, identity: str) -> Record | None:
        def get(connection: sqlite3.Connection) -> Record | None:
            row = connection.execute("SELECT * FROM memory_versions WHERE workspace_id=? AND id=? ORDER BY version DESC LIMIT 1",
                                     (workspace_id, identity)).fetchone()
            return self._memory(row) if row is not None else None
        return await self._run(get)

    async def memory_versions(self, workspace_id: str, identity: str) -> list[Record]:
        return await self._run(lambda connection: [self._memory(row) for row in connection.execute(
            "SELECT * FROM memory_versions WHERE workspace_id=? AND id=? ORDER BY version", (workspace_id, identity))])

    async def revise_memory(self, workspace_id: str, identity: str, expected_version: int,
                            replacement: Record | None) -> Record | None:
        def revise(connection: sqlite3.Connection) -> Record | None:
            row = connection.execute("SELECT * FROM memory_versions WHERE workspace_id=? AND id=? ORDER BY version DESC LIMIT 1",
                                     (workspace_id, identity)).fetchone()
            if row is None:
                return None
            current = self._memory(row)
            if current["version"] != expected_version or current["deleted"]:
                raise ValueError("Memory changed or was deleted; reload its current version.")
            values = replacement or current
            origin = {"kind": "user", "note": values["source_note"]} if replacement else current["origin"]
            connection.execute("INSERT INTO memory_versions VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (identity, workspace_id, expected_version + 1, values["title"], values["content"], values["kind"],
                 json.dumps(values["keywords"], ensure_ascii=False), json.dumps(origin, ensure_ascii=False),
                 int(replacement is None), current["created_at"], now()))
            saved = connection.execute("SELECT * FROM memory_versions WHERE id=? AND version=?",
                                       (identity, expected_version + 1)).fetchone()
            assert saved is not None
            return self._memory(saved)
        return await self._run(revise)

    async def add_session(self, workspace_id: str, title: str) -> Record:
        session = {"id": uuid4().hex, "workspace_id": workspace_id, "title": title, "created_at": now()}
        await self._run(lambda connection: connection.execute(
            "INSERT INTO sessions VALUES (:id, :workspace_id, :title, :created_at)", session,
        ))
        return session

    async def sessions(self) -> list[Record]:
        return await self._run(lambda connection: [dict(row) for row in connection.execute(
            "SELECT * FROM sessions ORDER BY rowid DESC"
        )])

    async def session(self, identity: str) -> Record | None:
        def get(connection: sqlite3.Connection) -> Record | None:
            row = connection.execute("SELECT * FROM sessions WHERE id=?", (identity,)).fetchone()
            return dict(row) if row else None

        return await self._run(get)

    @staticmethod
    def _event(connection: sqlite3.Connection, identity: str, kind: str, data: Record) -> None:
        sequence = connection.execute(
            "SELECT COALESCE(MAX(sequence), 0)+1 FROM events WHERE run_id=?", (identity,)
        ).fetchone()[0]
        connection.execute("INSERT INTO events VALUES (?, ?, ?, ?, ?)", (
            identity, sequence, kind, json.dumps(data, ensure_ascii=False), now(),
        ))

    def _select_memories(self, connection: sqlite3.Connection, workspace_id: str, task: str,
                         sources: list[Record], limits: Record) -> tuple[list[Record], list[Record]]:
        selected: list[Record] = []
        omitted: list[Record] = []
        relevance = (task + " " + " ".join(source["path"] for source in sources)).casefold()
        for row in connection.execute(
            "SELECT * FROM memory_versions m WHERE workspace_id=? AND deleted=0 AND "
            "version=(SELECT MAX(version) FROM memory_versions WHERE id=m.id) ORDER BY created_at, id", (workspace_id,)):
            memory = self._memory(row)
            reason = None
            if memory["keywords"] and not any(word.casefold() in relevance for word in memory["keywords"]):
                reason = "not_relevant"
            elif len(json.dumps(selected + [memory], ensure_ascii=False).encode("utf-8")) > limits.get("max_memory_bytes", 1024):
                reason = "memory_budget"
            if reason:
                omitted.append({"memory_id": memory["id"], "version": memory["version"], "reason": reason})
            else:
                selected.append(memory)
        return selected, omitted

    async def current_memories(self, identity: str) -> tuple[list[Record], list[Record]]:
        def select(connection: sqlite3.Connection) -> tuple[list[Record], list[Record]]:
            run = connection.execute("SELECT runs.*, sessions.workspace_id FROM runs JOIN sessions ON sessions.id=runs.session_id WHERE runs.id=?", (identity,)).fetchone()
            assert run is not None
            return self._select_memories(connection, run["workspace_id"], run["task"], json.loads(run["sources_json"]), json.loads(run["limits_json"]))
        return await self._run(select)

    @staticmethod
    def _submission(connection: sqlite3.Connection, session_id: str, key: str, digest: str) -> str | None:
        row = connection.execute("SELECT * FROM submissions WHERE session_id=? AND key=?", (session_id, key)).fetchone()
        if row is None:
            return None
        if row["request_sha256"] != digest:
            raise ValueError("This submission key already belongs to different request content.")
        return str(row["run_id"])

    async def submission(self, session_id: str, key: str, digest: str) -> Record | None:
        identity = await self._run(lambda connection: self._submission(connection, session_id, key, digest))
        return await self.run(identity) if identity is not None else None

    async def add_run(self, session_id: str, task: str, sources: list[Record], limits: Record, model: Record,
                      validation: Record | None = None, policy: Record | None = None,
                      base_reference: Record | None = None, source_excerpts: list[Record] | None = None,
                      submission_key: str | None = None, request_sha256: str = "") -> tuple[Record, bool]:
        identity = uuid4().hex

        def add(connection: sqlite3.Connection) -> tuple[str, bool]:
            if submission_key is not None:
                previous = self._submission(connection, session_id, submission_key, request_sha256)
                if previous is not None:
                    return previous, False
            active = connection.execute(
                "SELECT id FROM runs WHERE session_id=? AND status IN ('queued', 'running', 'waiting_approval', 'cancel_requested')", (session_id,)
            ).fetchone()
            if active:
                raise ValueError("This Session already has an active Run.")
            base = None
            context: Record = {"turns": [], "history": [], "history_run_ids": [], "omitted": []}
            session = connection.execute("SELECT workspace_id FROM sessions WHERE id=?", (session_id,)).fetchone()
            assert session is not None
            context["source_excerpts"] = source_excerpts or []
            context["memories"], context["memory_omitted"] = self._select_memories(connection, session[0], task, sources, limits)
            if base_reference is not None:
                parent_run = connection.execute("SELECT * FROM runs WHERE id=?", (base_reference["run_id"],)).fetchone()
                artifact = connection.execute("SELECT * FROM artifacts WHERE run_id=? AND id=?",
                                              (base_reference["run_id"], base_reference["artifact_id"])).fetchone()
                if parent_run is None or parent_run["session_id"] != session_id or parent_run["status"] != "completed" or artifact is None:
                    raise RunFailure("invalid_base_artifact", "Choose an artifact from a completed Run in this Session.")
                try:
                    raw = (self.directory / "artifacts" / artifact["id"]).read_bytes()
                    if hashlib.sha256(raw).hexdigest() != artifact["sha256"]:
                        raise ValueError("Hash mismatch")
                    base = {**self._artifact(artifact), "text": raw.decode("utf-8"),
                            "sources": json.loads(parent_run["sources_json"])}
                except (OSError, UnicodeError, ValueError) as error:
                    raise RunFailure("base_artifact_unavailable", "The exact saved base artifact cannot be verified.") from error
                admitted = {(source["path"], source["sha256"]) for source in sources}
                if all((source["path"], source["sha256"]) in admitted for source in base["sources"]):
                    prior = json.loads(parent_run["context_json"] or "{}")
                    events = [{**dict(row), "data": json.loads(row["data_json"])} for row in connection.execute(
                        "SELECT * FROM events WHERE run_id=? ORDER BY sequence", (parent_run["id"],))]
                    turns = prior.get("turns", []) + [{"run_id": parent_run["id"],
                        "messages": history_turn(parent_run["id"], parent_run["task"], events)}]
                    budget = limits.get("max_history_bytes", 16384)
                    while turns and len(json.dumps([message for turn in turns for message in turn["messages"]], ensure_ascii=False).encode("utf-8")) > budget:
                        removed = turns.pop(0)
                        context["omitted"].append({"run_id": removed["run_id"], "reason": "history_budget"})
                    context["turns"] = turns
                    context["history"] = [message for turn in turns for message in turn["messages"]]
                    context["history_run_ids"] = [turn["run_id"] for turn in turns]
                else:
                    context["omitted"] = [{"run_id": parent_run["id"], "reason": "sources_not_selected_at_same_version"}]
            connection.execute(
                "INSERT INTO runs (id, session_id, task, sources_json, limits_json, status, mode, created_at, model_json, validation_json, policy_json, base_json, context_json) "
                "VALUES (?, ?, ?, ?, ?, 'queued', ?, ?, ?, ?, ?, ?, ?)",
                (identity, session_id, task, json.dumps(sources), json.dumps(limits), model["mode"], now(), json.dumps(model), json.dumps(validation or {}), json.dumps(policy or {}), json.dumps(base), json.dumps(context)),
            )
            if submission_key is not None:
                connection.execute("INSERT INTO submissions VALUES (?, ?, ?, ?)",
                                   (session_id, submission_key, request_sha256, identity))
            self._event(connection, identity, "run.accepted", {"mode": model["mode"], "model": model, "validation": validation or {}, "policy": policy or {}})
            return identity, True

        accepted_id, created = await self._run(add)
        result = await self.run(accepted_id)
        assert result is not None
        return result, created

    @staticmethod
    def _artifact(row: sqlite3.Row) -> Record:
        result = dict(row)
        result["download_url"] = f"/api/runs/{row['run_id']}/artifacts/{row['id']}"
        return result

    async def run(self, identity: str) -> Record | None:
        def get(connection: sqlite3.Connection) -> Record | None:
            row = connection.execute("SELECT * FROM runs WHERE id=?", (identity,)).fetchone()
            if row is None:
                return None
            result = dict(row)
            result["sources"] = json.loads(result.pop("sources_json"))
            result["limits"] = json.loads(result.pop("limits_json"))
            result["model"] = json.loads(result.pop("model_json"))
            result["validation"] = json.loads(result.pop("validation_json"))
            result["policy"] = json.loads(result.pop("policy_json"))
            result["context"] = json.loads(result.pop("context_json") or "{}")
            result["base_artifact"] = json.loads(result.pop("base_json") or "null")
            result["cancellation"] = json.loads(result.pop("cancellation_json") or "null")
            result["error"] = json.loads(result.pop("error_json") or "null")
            result["usage"] = {"model_calls": result.pop("model_calls"), "tool_calls": result.pop("tool_calls")}
            result["artifacts"] = [self._artifact(artifact) for artifact in connection.execute(
                "SELECT * FROM artifacts WHERE run_id=? ORDER BY rowid", (identity,)
            )]
            result["approvals"] = [self._approval(approval) for approval in connection.execute(
                "SELECT * FROM approvals WHERE run_id=? ORDER BY rowid", (identity,)
            )]
            result["last_sequence"] = connection.execute("SELECT COALESCE(MAX(sequence), 0) FROM events WHERE run_id=?", (identity,)).fetchone()[0]
            return result

        return await self._run(get)

    async def session_runs(self, session_id: str) -> list[Record]:
        identities = await self._run(lambda connection: [row[0] for row in connection.execute(
            "SELECT id FROM runs WHERE session_id=? ORDER BY rowid", (session_id,)
        )])
        result = []
        for identity in identities:
            run = await self.run(identity)
            if run is not None:
                result.append(run)
        return result

    async def record(
        self, identity: str, kind: str, data: Record, *, status: str | None = None,
        usage: Record | None = None, result: str | None = None, error: Record | None = None,
    ) -> None:
        def save(connection: sqlite3.Connection) -> None:
            current = connection.execute("SELECT status FROM runs WHERE id=?", (identity,)).fetchone()
            if current is None or current[0] in TERMINAL:
                return
            if current[0] == "cancel_requested":
                return
            if status is not None:
                connection.execute("UPDATE runs SET status=? WHERE id=?", (status, identity))
            if usage is not None:
                connection.execute("UPDATE runs SET model_calls=?, tool_calls=? WHERE id=?", (
                    usage["model_calls"], usage["tool_calls"], identity,
                ))
            if result is not None:
                connection.execute("UPDATE runs SET result=? WHERE id=?", (result, identity))
            if error is not None:
                connection.execute("UPDATE runs SET error_json=? WHERE id=?", (json.dumps(error), identity))
            if status in TERMINAL:
                for approval in connection.execute("SELECT * FROM approvals WHERE run_id=? AND status IN ('pending','approved')", (identity,)).fetchall():
                    connection.execute("UPDATE approvals SET status='expired' WHERE id=?", (approval["id"],))
                    self._event(connection, identity, "approval.expired", {"id": approval["id"], "reason": status})
            self._event(connection, identity, kind, data)

        await self._run(save)

    async def request_cancel(self, identity: str) -> None:
        def save(connection: sqlite3.Connection) -> None:
            run = connection.execute("SELECT status FROM runs WHERE id=?", (identity,)).fetchone()
            if run is None or run[0] in TERMINAL or run[0] == "cancel_requested":
                return
            connection.execute("UPDATE runs SET status='cancel_requested', cancellation_json=? WHERE id=?", (json.dumps({"outcome": "pending"}), identity))
            for approval in connection.execute("SELECT id FROM approvals WHERE run_id=? AND status IN ('pending','approved')", (identity,)).fetchall():
                connection.execute("UPDATE approvals SET status='cancelled' WHERE id=?", (approval["id"],))
                self._event(connection, identity, "approval.cancelled", {"id": approval["id"]})
            self._event(connection, identity, "run.cancel_requested", {})
        await self._run(save)

    async def complete_cancel(self, identity: str, *, background_work_may_finish: bool = False) -> None:
        def save(connection: sqlite3.Connection) -> None:
            run = connection.execute("SELECT status FROM runs WHERE id=?", (identity,)).fetchone()
            if run is None or run[0] != "cancel_requested":
                return
            count = connection.execute("SELECT COUNT(*) FROM artifacts WHERE run_id=?", (identity,)).fetchone()[0]
            uncertain: dict[str, Record] = {}
            for row in connection.execute("SELECT kind, data_json FROM events WHERE run_id=? AND kind IN ('tool.dispatched','tool.completed','tool.failed') ORDER BY sequence", (identity,)):
                data = json.loads(row["data_json"])
                if row["kind"] == "tool.dispatched" and data.get("effect") not in {"read_only", "run_metadata"}:
                    uncertain[data["call_id"]] = {"call_id": data["call_id"], "tool": data["tool"]}
                elif row["kind"] in {"tool.completed", "tool.failed"}:
                    uncertain.pop(data["call_id"], None)
            result = {"outcome": "unknown_effects" if uncertain else "stopped", "completed_artifacts": count, "runner_stopped": True,
                      "background_work_may_finish": background_work_may_finish, "uncertain_attempts": list(uncertain.values())}
            for attempt in uncertain.values():
                self._event(connection, identity, "tool.unknown", {**attempt, "reason": "cancelled_before_result_acknowledgement"})
            connection.execute("UPDATE runs SET status='cancelled', cancellation_json=? WHERE id=?", (json.dumps(result), identity))
            self._event(connection, identity, "run.cancelled", result)
        await self._run(save)

    async def events(self, identity: str, after: int = 0, *, limit: int | None = None) -> list[Record]:
        def get(connection: sqlite3.Connection) -> list[Record]:
            result = []
            for row in connection.execute(
                "SELECT * FROM events WHERE run_id=? AND sequence>? ORDER BY sequence LIMIT ?", (identity, after, limit if limit is not None else -1)
            ):
                event = dict(row)
                event["data"] = json.loads(event.pop("data_json"))
                result.append(event)
            return result

        return await self._run(get)

    async def event_position(self, identity: str) -> Record | None:
        def get(connection: sqlite3.Connection) -> Record | None:
            row = connection.execute("SELECT status, (SELECT COALESCE(MAX(sequence), 0) FROM events WHERE run_id=runs.id) AS last_sequence FROM runs WHERE id=?", (identity,)).fetchone()
            return dict(row) if row is not None else None
        return await self._run(get)

    @staticmethod
    def _approval(row: sqlite3.Row) -> Record:
        value = dict(row)
        value["arguments"] = json.loads(value.pop("arguments_json"))
        value["scope"] = json.loads(value.pop("scope_json"))
        return value

    async def request_approval(self, identity: str, prepared: PreparedCall) -> Record:
        def save(connection: sqlite3.Connection) -> Record:
            run = connection.execute("SELECT * FROM runs WHERE id=?", (identity,)).fetchone()
            if run is None or run["status"] != "running":
                raise RunFailure("run_not_active", "Only an active Run can request approval.")
            limits = json.loads(run["limits_json"])
            created = datetime.now(timezone.utc)
            expires = min(created + timedelta(seconds=limits.get("approval_timeout_seconds", 120)),
                          datetime.fromisoformat(run["created_at"]) + timedelta(seconds=limits["timeout_seconds"]))
            approval_id = uuid4().hex
            connection.execute("INSERT INTO approvals VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?)", (
                approval_id, identity, prepared.call.identity, prepared.call.name,
                json.dumps(prepared.arguments), json.dumps(prepared.scope), prepared.digest(identity), created.isoformat(), expires.isoformat(),
            ))
            connection.execute("UPDATE runs SET status='waiting_approval' WHERE id=?", (identity,))
            row = connection.execute("SELECT * FROM approvals WHERE id=?", (approval_id,)).fetchone()
            assert row is not None
            approval = self._approval(row)
            self._event(connection, identity, "approval.requested", approval)
            return approval
        return await self._run(save)

    async def approval(self, identity: str, approval_id: str) -> Record | None:
        def get(connection: sqlite3.Connection) -> Record | None:
            row = connection.execute("SELECT * FROM approvals WHERE run_id=? AND id=?", (identity, approval_id)).fetchone()
            return self._approval(row) if row else None
        return await self._run(get)

    async def decide_approval(self, identity: str, approval_id: str, decision: str, digest: str) -> Record | None:
        def save(connection: sqlite3.Connection) -> Record | None:
            row = connection.execute("SELECT a.*, r.status AS run_status FROM approvals a JOIN runs r ON r.id=a.run_id WHERE a.run_id=? AND a.id=?", (identity, approval_id)).fetchone()
            if row is None:
                return None
            if row["status"] != "pending" or row["run_status"] != "waiting_approval" or datetime.now(timezone.utc) >= datetime.fromisoformat(row["expires_at"]):
                raise ValueError("This approval is no longer pending or has expired.")
            if digest != row["parameters_sha256"]:
                raise ValueError("The approval does not match the reviewed parameters.")
            status = "approved" if decision == "approve" else "denied"
            connection.execute("UPDATE approvals SET status=? WHERE id=?", (status, approval_id))
            connection.execute("UPDATE runs SET status='running' WHERE id=?", (identity,))
            self._event(connection, identity, f"approval.{status}", {"id": approval_id, "parameters_sha256": digest})
            updated = connection.execute("SELECT * FROM approvals WHERE id=?", (approval_id,)).fetchone()
            assert updated is not None
            return self._approval(updated)
        return await self._run(save)

    async def dispatch(self, identity: str, prepared: PreparedCall, approval_id: str | None = None) -> PreparedCall:
        def save(connection: sqlite3.Connection) -> PreparedCall:
            run = connection.execute("SELECT * FROM runs WHERE id=?", (identity,)).fetchone()
            if run is None or run["status"] != "running":
                raise RunFailure("run_not_active", "The Run is not allowed to dispatch tools.")
            policy = json.loads(run["policy_json"])
            arguments, scope = prepared.arguments, prepared.scope
            if prepared.call.name == "artifact_write" and policy.get("require_publish_approval"):
                row = connection.execute("SELECT * FROM approvals WHERE run_id=? AND id=?", (identity, approval_id)).fetchone()
                if row is None or row["status"] != "approved" or row["call_id"] != prepared.call.identity or row["tool"] != prepared.call.name or row["parameters_sha256"] != prepared.digest(identity):
                    raise RunFailure("approval_required", "A matching single-use approval is required.")
                if datetime.now(timezone.utc) >= datetime.fromisoformat(row["expires_at"]):
                    raise RunFailure("approval_expired", "The reviewed operation expired before dispatch.")
                arguments, scope = json.loads(row["arguments_json"]), json.loads(row["scope_json"])
                connection.execute("UPDATE approvals SET status='consumed' WHERE id=?", (approval_id,))
                self._event(connection, identity, "approval.consumed", {"id": approval_id, "call_id": prepared.call.identity})
            self._event(connection, identity, "tool.dispatched", {"call_id": prepared.call.identity, "tool": prepared.call.name,
                         "effect": prepared.scope["effect"]})
            return PreparedCall(prepared.call, deepcopy(arguments), deepcopy(scope))
        return await self._run(save)

    async def publish(self, identity: str, name: str, content: str) -> Record:
        artifact_id = uuid4().hex
        raw = content.encode("utf-8")
        directory = self.directory / "artifacts"

        def save(connection: sqlite3.Connection) -> Record:
            run = connection.execute("SELECT status, base_json FROM runs WHERE id=?", (identity,)).fetchone()
            if run is None or run[0] != "running":
                raise RunFailure("run_not_active", "Artifacts can only be published by an active Run.")
            directory.mkdir(exist_ok=True)
            path = directory / artifact_id
            try:
                with path.open("xb") as output:
                    output.write(raw)
                base = json.loads(run["base_json"] or "null")
                connection.execute("INSERT INTO artifacts (id, run_id, name, sha256, bytes, parent_artifact_id, version) VALUES (?, ?, ?, ?, ?, ?, ?)", (
                    artifact_id, identity, name, hashlib.sha256(raw).hexdigest(), len(raw),
                    base["id"] if base else None, base["version"] + 1 if base else 1,
                ))
                row = connection.execute("SELECT * FROM artifacts WHERE id=?", (artifact_id,)).fetchone()
                assert row is not None
                artifact = self._artifact(row)
                self._event(connection, identity, "artifact.published", artifact)
                return artifact
            except Exception:
                path.unlink(missing_ok=True)
                raise

        return await self._run(save)

    async def artifact(self, run_id: str, artifact_id: str) -> Record | None:
        def get(connection: sqlite3.Connection) -> Record | None:
            row = connection.execute("SELECT * FROM artifacts WHERE run_id=? AND id=?", (run_id, artifact_id)).fetchone()
            return self._artifact(row) if row else None

        return await self._run(get)
