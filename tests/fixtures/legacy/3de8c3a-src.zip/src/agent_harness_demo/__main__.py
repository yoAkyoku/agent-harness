import argparse
from pathlib import Path

import uvicorn

from .web import create_app
from .model import ModelSettings


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the local Agent Harness workbench.")
    parser.add_argument("--store", type=Path, default=Path(".private/workbench"))
    parser.add_argument("--port", type=int, default=8787)
    parser.add_argument("--model", help="Exact already-installed Ollama model name; omit for the scripted fixture.")
    parser.add_argument("--fault-once-source-read", action="store_true", help="Controlled validation: fail each Run's first source_read before filesystem access.")
    parser.add_argument("--hold-first-tool", choices=["source_read", "artifact_write"], help="Controlled validation: hold the service's first matching read before access, or publish before result acknowledgement.")
    arguments = parser.parse_args()
    if not 1 <= arguments.port <= 65535:
        parser.error("--port must be between 1 and 65535")
    try:
        settings = ModelSettings.local(arguments.model) if arguments.model else ModelSettings()
    except ValueError as error:
        parser.error(str(error))
    uvicorn.run(create_app(arguments.store.resolve(), model_settings=settings, fault_once_source_read=arguments.fault_once_source_read,
                           hold_first_tool=arguments.hold_first_tool),
                host="127.0.0.1", port=arguments.port, access_log=False)


if __name__ == "__main__":
    main()
