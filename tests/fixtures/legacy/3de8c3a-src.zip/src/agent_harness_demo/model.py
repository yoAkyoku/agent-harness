"""Chat Completions serialization and a clearly identified scripted transport."""

import json
from dataclasses import dataclass
import re
from typing import Any, Literal

import httpx

from .contracts import Decision, RunFailure, ToolCall
from .streaming import MAX_RESPONSE_BYTES, TextSink, read_chat_stream, token_usage


@dataclass(frozen=True)
class ModelSettings:
    mode: Literal["fixture", "local"] = "fixture"
    name: str = "fixture-script-v1"
    stream: bool = False
    context_window_tokens: int = 8192

    def __post_init__(self) -> None:
        if type(self.context_window_tokens) is not int or not 4096 <= self.context_window_tokens <= 262144:
            raise ValueError("Choose an explicit bounded context capacity.")
        if self.mode not in {"fixture", "local"} or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._:/-]{0,99}", self.name):
            raise ValueError("Choose a valid explicit local model name.")
        if self.mode == "local" and "cloud" in self.name.lower():
            raise ValueError("Cloud model identifiers are not supported.")
        if self.mode == "fixture" and (self.name != "fixture-script-v1" or self.stream):
            raise ValueError("The fixture profile uses its fixed non-streaming transport.")

    @classmethod
    def local(cls, name: str, *, stream: bool = True) -> "ModelSettings":
        return cls(mode="local", name=name, stream=stream)

    @property
    def endpoint(self) -> str:
        if self.mode == "local":
            return "http://127.0.0.1:11434/v1/chat/completions"
        return "https://fixture.invalid/v1/chat/completions"


class ModelAdapter:
    def __init__(self, client: httpx.AsyncClient, settings: ModelSettings, *, transport_fixture: bool) -> None:
        self.client = client
        self.settings = settings
        self.info: dict[str, Any] = {
            "mode": settings.mode, "name": settings.name, "endpoint": settings.endpoint,
            "stream": settings.stream, "transport_fixture": transport_fixture,
            "context_capacity_tokens": settings.context_window_tokens if settings.mode == "local" else 16777216,
            "context_capacity_source": "application_configuration" if settings.mode == "local" else "synthetic_fixture",
            "context_profile": "synthetic_fixture",
        }

    async def prepare(self) -> None:
        if self.settings.mode == "fixture":
            return
        base = "http://127.0.0.1:11434"
        try:
            version = await self.client.get(base + "/api/version", timeout=5)
            tags = await self.client.get(base + "/api/tags", timeout=5)
            show = await self.client.post(base + "/api/show", json={"model": self.settings.name}, timeout=10)
            for response in (version, tags, show):
                response.raise_for_status()
            models = tags.json()["models"]
            found = next((model for model in models if model["name"] == self.settings.name), None)
            metadata = show.json()
            if metadata.get("remote_model") or metadata.get("remote_host"):
                raise RunFailure("remote_model_forbidden", "Only already-downloaded local model weights are supported.")
            if found is None or not re.fullmatch(r"[a-fA-F0-9]{64}", found.get("digest", "")):
                raise RunFailure("model_not_installed", "The configured local model is not present with a valid digest.")
            if "tools" not in metadata.get("capabilities", []):
                raise RunFailure("model_tools_unavailable", "The configured model does not advertise tool calling.")
            server_version = version.json()["version"]
            info = metadata.get("model_info", {})
            profile_matches = (server_version == "0.40.10" and metadata.get("renderer") == "qwen3.5"
                and metadata.get("parser") == "qwen3.5" and metadata.get("template_source") == "renderer_parser"
                and metadata.get("template") == "{{ .Prompt }}" and not metadata.get("messages") and not metadata.get("system")
                and info.get("general.architecture") == "qwen35" and info.get("tokenizer.ggml.model") == "gpt2"
                and info.get("tokenizer.ggml.pre") == "qwen35" and info.get("tokenizer.ggml.add_bos_token") is False)
            if profile_matches:
                self.info["context_profile"] = "ollama-0.40.10-qwen35-gpt2"
                self.info["renderer_verification"] = {"renderer": metadata["renderer"], "parser": metadata["parser"],
                    "template_source": metadata["template_source"], "implicit_messages": False, "implicit_system": False,
                    "tokenizer_model": info["tokenizer.ggml.model"], "tokenizer_pre": info["tokenizer.ggml.pre"], "add_bos_token": False}
            elif not self.info["transport_fixture"] or metadata.get("renderer") == "qwen3.5" or server_version == "0.40.10":
                raise RunFailure("context_profile_unsupported", "The local renderer/tokenizer profile has no verified context bound.")
            self.info.update({"digest": found["digest"], "server_version": version.json()["version"],
                              "capabilities": metadata["capabilities"], "reasoning_effort": "none"})
        except httpx.HTTPError as error:
            raise RunFailure("model_unavailable", "Start the configured local Ollama service and use an already-installed model.") from error
        except (KeyError, TypeError, ValueError) as error:
            raise RunFailure("model_metadata_invalid", "The local model metadata could not be verified.") from error

    def request_body(self, messages: list[dict[str, Any]], tools: list[dict[str, Any]], max_output_tokens: int) -> dict[str, Any]:
        body: dict[str, Any] = {"model": self.settings.name, "messages": messages, "tools": tools,
                                "stream": self.settings.stream, "max_tokens": max_output_tokens}
        if self.settings.mode == "local":
            body.update({"temperature": 0, "reasoning_effort": "none"})
        if self.settings.stream:
            body["stream_options"] = {"include_usage": True}
        return body

    async def decide(
        self, messages: list[dict[str, Any]], tools: list[dict[str, Any]], on_text: TextSink | None = None,
        *, max_output_tokens: int = 2048,
    ) -> Decision:
        try:
            body = self.request_body(messages, tools, max_output_tokens)
            if self.settings.stream:
                async with self.client.stream("POST", self.settings.endpoint, json=body) as response:
                    response.raise_for_status()
                    payload = await read_chat_stream(response, on_text)
            else:
                response = await self.client.post(self.settings.endpoint, json=body)
                response.raise_for_status()
                if len(response.content) > MAX_RESPONSE_BYTES:
                    raise RunFailure("model_response_too_large", "The model response exceeded its size limit.")
                payload = response.json()
        except httpx.HTTPError as error:
            raise RunFailure("model_unavailable", "The model transport did not return a usable response.") from error
        except ValueError as error:
            raise RunFailure("model_protocol_error", "The model did not return valid JSON.") from error
        try:
            raw = payload["choices"][0]["message"]
            text = raw.get("content") or ""
            if not isinstance(text, str) or len(text.encode("utf-8")) > 262_144:
                raise ValueError
            calls = []
            tool_calls = raw.get("tool_calls") or []
            if not isinstance(tool_calls, list) or len(tool_calls) > 50:
                raise ValueError
            for item in tool_calls:
                arguments = json.loads(item["function"]["arguments"])
                identity, name = item["id"], item["function"]["name"]
                if not isinstance(arguments, dict) or not isinstance(identity, str) or not identity:
                    raise ValueError
                if not isinstance(name, str):
                    raise ValueError
                calls.append(ToolCall(identity, name, arguments))
            if not calls and not text:
                raise ValueError
            message: dict[str, Any] = {"role": "assistant", "content": text or None}
            if calls:
                message["tool_calls"] = raw["tool_calls"]
            return Decision(text, tuple(calls), message, token_usage(payload.get("usage")))
        except (KeyError, IndexError, TypeError, ValueError, AttributeError) as error:
            raise RunFailure("model_protocol_error", "The model response has an invalid tool or message format.") from error


class FixtureTransport:
    """A deterministic source snapshot recipe; it does not interpret task intent."""

    async def __call__(self, request: httpx.Request) -> httpx.Response:
        messages = json.loads(request.content)["messages"]
        current = max(index for index, message in enumerate(messages) if message["role"] == "user")
        results = [json.loads(item["content"]) for item in messages[current+1:] if item["role"] == "tool"]
        if not results:
            return self._call("workspace_list", {}, "catalog")
        sources = results[0]["sources"]
        read_count = len(results) - 1
        if read_count < len(sources):
            return self._call("source_read", {"path": sources[read_count]["path"]}, f"read-{read_count}")
        if read_count == len(sources):
            sections = ["# 來源快照", "此成果由模擬模型依固定示範步驟建立。\n"]
            for result in results[1:]:
                sections.append(f"## {result['path']}\n\n{result['text']}")
            return self._call("artifact_write", {"name": "source-snapshot.md", "content": "\n\n".join(sections)}, "publish")
        return httpx.Response(200, json={"choices": [{"message": {
            "role": "assistant", "content": "來源快照已保存，可在右側預覽或下載。",
        }}]})

    @staticmethod
    def _call(name: str, arguments: dict[str, Any], identity: str) -> httpx.Response:
        return httpx.Response(200, json={"choices": [{"message": {
            "role": "assistant", "content": None,
            "tool_calls": [{"id": identity, "type": "function", "function": {
                "name": name, "arguments": json.dumps(arguments, ensure_ascii=False),
            }}],
        }}]})
